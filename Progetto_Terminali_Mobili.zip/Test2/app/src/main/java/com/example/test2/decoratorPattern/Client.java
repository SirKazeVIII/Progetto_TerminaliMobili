package com.example.test2.decoratorPattern;

/**
 * Classe astratta per la dichiarazione del tipo sensore, del nome e del suo consumo.
 */


public abstract class Client {

    String TipoSensore = "";

    public String getTipoSensore() {
        return TipoSensore;
    }
    public abstract String getNomeSensore();

    public abstract int getConsumo();

}
