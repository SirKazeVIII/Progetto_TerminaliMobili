package com.example.test2.dataBase;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class GestioneDataBaseSQLite extends SQLiteOpenHelper {

    //Classe Per La Gestione del DataBase in SQLite

    private Context context;
    private static final String NOMEDATABASE = "LaMiaCasaDomoticaDB";
    private static final int VERSIONEDATABASE = 1;


    //Tabella Sensori Monitoraggio
    private static final String DATABASE_TABELLA = "sensori_monitoraggio";
    private static final String KEY_NOME_SM = "nome_sm";
    private static final String KEY_TIPO_CONSUMO_SM = "tipo_consumo_sm";
    private static final String KEY_CONSUMO_SM = "consumo_sm";
    private static final String KEY_SENSORE_ATTIVATO = "sensore_attivato";
    private static final String KEY_ADDON_SM = "addon_sm";

    //Tabella Sensori Attivabili
    private static final String DATABASE_TABELLA_2 = "sensori_attivabili";
    private static final String KEY_NOME_SA = "nome_sa";
    private static final String KEY_TIPO_CONSUMO_SA = "tipo_consumo_sa";
    private static final String KEY_CONSUMO_SA = "consumo_sa";
    private static final String KEY_TEMPO_ATTIVAZIONE = "tempo_attivazione";
    private static final String KEY_ADDON_SA = "addon_sa";

    //Tabella Allarme
    private static final String DATABASE_TABELLA_3 = "allarmi";
    private static final String KEY_ID = "id";
    private static final String KEY_DATA_INIZIO = "data_inizio";
    private static final String KEY_DATA_FINE = "data_fine";


    public GestioneDataBaseSQLite(@Nullable Context context) {
        super(context, NOMEDATABASE, null, VERSIONEDATABASE);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Creazione Tabella Sensori Monitoraggio
        String DATABASE_CREAZIONE = "CREATE TABLE " + DATABASE_TABELLA +
                " ( " + KEY_NOME_SM + " TEXT PRIMARY KEY, " +
                KEY_TIPO_CONSUMO_SM + " TEXT, " +
                KEY_CONSUMO_SM + " INTEGER, " +
                KEY_SENSORE_ATTIVATO + " TEXT, " +
                KEY_ADDON_SM + " TEXT );";

        //Creazione Tabella Sensori Attivabili
        String DATABASE_CREAZIONE_2 = " CREATE TABLE " + DATABASE_TABELLA_2 +
                " ( " + KEY_NOME_SA + " TEXT PRIMARY KEY, " +
                KEY_TIPO_CONSUMO_SA + " TEXT, " +
                KEY_CONSUMO_SA + " INTEGER, " +
                KEY_TEMPO_ATTIVAZIONE + " INTEGER, " +
                KEY_ADDON_SA + " TEXT );";

        //Creazione Tabella Allarmi
        String DATABASE_CREAZIONE_3 = " CREATE TABLE " + DATABASE_TABELLA_3 +
                " ( " + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                KEY_DATA_INIZIO + " TEXT, " +
                KEY_DATA_FINE + " TEXT );";

        db.execSQL(DATABASE_CREAZIONE);
        db.execSQL(DATABASE_CREAZIONE_2);
        db.execSQL(DATABASE_CREAZIONE_3);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABELLA);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABELLA_2);
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABELLA_3);
        onCreate(db);

    }

    //Metodo per Inserire Sensori di Monitoraggio
    public void inserisciSensoreMonitoraggio(String Nome_SM, String Tipo_Consumo_SM, int Consumo_SM, String Sensore_Attivato, String AddOn_SM) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues initialValues = new ContentValues();

        initialValues.put(KEY_NOME_SM, Nome_SM);
        initialValues.put(KEY_TIPO_CONSUMO_SM, Tipo_Consumo_SM);
        initialValues.put(KEY_CONSUMO_SM, Consumo_SM);
        initialValues.put(KEY_SENSORE_ATTIVATO, Sensore_Attivato);
        initialValues.put(KEY_ADDON_SM, AddOn_SM);

        long result = db.insert(DATABASE_TABELLA, null, initialValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Sensore Inserito", Toast.LENGTH_SHORT).show();
        }
    }

    //Metodo per Inserire Sensori Attivabili
    public void inserisciSensoreAttivabili (String Nome_SA, String Tipo_Consumo_SA, int Consumo_SA, int Tempo_Attivazione, String AddOn_SA){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues initialValues = new ContentValues();

        initialValues.put(KEY_NOME_SA, Nome_SA);
        initialValues.put(KEY_TIPO_CONSUMO_SA, Tipo_Consumo_SA);
        initialValues.put(KEY_CONSUMO_SA, Consumo_SA);
        initialValues.put(KEY_TEMPO_ATTIVAZIONE, Tempo_Attivazione);
        initialValues.put(KEY_ADDON_SA, AddOn_SA);

        long result = db.insert(DATABASE_TABELLA_2, null, initialValues);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Sensore Inserito", Toast.LENGTH_SHORT).show();
        }
    }

    //Metodo per Inserire Allarmi
    public void inserisciAllarmi (Integer ID, String Data_Inizio, String Data_Fine){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues initialValues = new ContentValues();

        initialValues.put(KEY_ID, ID);
        initialValues.put(KEY_DATA_INIZIO, Data_Inizio);
        initialValues.put(KEY_DATA_FINE, Data_Fine);

        long result = db.insert(DATABASE_TABELLA_3, null, initialValues);
        if (result == -1) {
            //Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            //Toast.makeText(context, "Allarme inserito", Toast.LENGTH_SHORT).show();
        }
    }

    //Metodo per Visualizzare i Sensori di Monitoraggio
    public Cursor visualizzaSensoriMonitoraggio(){
        String queryALLSM = " SELECT * FROM " +DATABASE_TABELLA;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
           cursor = db.rawQuery(queryALLSM, null);
        }
        return cursor;
        }

    //Metodo per Visualizzare i Sensori di Attivabili
    public Cursor visualizzaSensoriAttivabili(){
        String queryALLSM = " SELECT * FROM " +DATABASE_TABELLA_2;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(queryALLSM, null);
        }
        return cursor;
    }

    //Metodo per Visualizzare gli Allarmi
    public Cursor visualizzaAllarmi(){
        String queryALLSM = " SELECT * FROM " +DATABASE_TABELLA_3;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(queryALLSM, null);
        }
        return cursor;
    }

    //Metodo per Aggiungere AddOn ad un Sensore di Monitoraggio
    public void aggiungiAddOnSM(String row_nome_sm, String add_on_sm, int consumoSM){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(KEY_ADDON_SM, add_on_sm);
        cv.put(KEY_CONSUMO_SM, consumoSM);
        long result = db.update(DATABASE_TABELLA, cv, "nome_sm=?", new String[] {row_nome_sm});
        if (result == -1){
            Toast.makeText(context, "Errore", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "AddOn Aggiunto", Toast.LENGTH_SHORT).show();
        }
    }

    //Metodo per Cancellare un Sensore di Monitoraggio
    public void cancellaSensoreMonitoraggio (String row_nome_sm) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(DATABASE_TABELLA, "nome_sm=?", new String[]{row_nome_sm});
        if (result == -1){
            Toast.makeText(context, "Errore", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "Eliminazione Riuscita", Toast.LENGTH_SHORT).show();
        }
    }

    //Metodo per Aggiungere AddOn ad un Sensore di Attivabile
    public void aggiungiAddOnSA(String row_nome_sa, String add_on_sa, int consumoSA){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(KEY_ADDON_SA, add_on_sa);
        cv.put(KEY_CONSUMO_SA, consumoSA);
        long result = db.update(DATABASE_TABELLA_2, cv, "nome_sa=?", new String[] {row_nome_sa});
        if (result == -1){
            Toast.makeText(context, "Errore", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "AddOn Aggiunto", Toast.LENGTH_SHORT).show();
        }
    }

    //Metodo per Cancellare un Sensore Attivabile
    public void cancellaSensoreAttivabile (String row_nome_sa) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(DATABASE_TABELLA_2, "nome_sa=?", new String[]{row_nome_sa});
        if (result == -1){
            Toast.makeText(context, "Errore", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "Eliminazione Riuscita", Toast.LENGTH_SHORT).show();
        }
    }

    //Metodo per CAncellare Tutti gli Allarmi
    public void resetAllarmi () {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(DATABASE_TABELLA_3, null, null);
        if (result == -1){
            Toast.makeText(context, "Errore", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "Eliminazione Riuscita", Toast.LENGTH_SHORT).show();
        }

    }
}
