package com.example.test2.decoratorPattern;


/**
 * Classe con tutti i Constructors per il Decorator Pattern di Sensore Attivo.
 */

public class DP_SensoriAttivabili extends Client{

    public DP_SensoriAttivabili () {
        TipoSensore = "Sensore Attivo";
    }

    @Override
    public String getNomeSensore() {
        return null;
    }

    @Override
    public int getConsumo() {
        return 10;
    }
}
