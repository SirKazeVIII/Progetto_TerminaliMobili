package com.example.test2;

import android.content.Context;
import android.database.Cursor;
import android.widget.Toast;

import com.example.test2.dataBase.GestioneDataBaseSQLite;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;
import java.util.Random;

public class CodaRun implements Runnable {

    private final Context context;
    GestioneDataBaseSQLite db;
    ArrayList<String> nome_sm, tipo_consumo_sm, consumo_sm, sensore_attivabile, addon_sm;
    ArrayList<String> nome_sa, tipo_consumo_sa, consumo_sa, tempoAttivazione, addon_sa;
    private Queue<Integer> coda = new ArrayDeque<Integer>();
    private volatile boolean exit = false;

    public CodaRun(Context context) {
        this.context = context;
    }

    public void codaTempi (Queue<Integer> coda) {
        this.coda = coda;
    }

    public Queue<Integer> getCoda() {
        return this.coda;
    }

    @Override
    public void run() {

        //Gestione e creazione Coda
        coda = getCoda();
        System.out.println(coda);
        int tempoAttivazioneConfronto = 0;
        String nomeConfronto = null;
        String nome = null;

        //DataBase
        db = new GestioneDataBaseSQLite(context);

        //Sensori di Monitoraggio
        nome_sm = new ArrayList<>();
        tipo_consumo_sm = new ArrayList<>();
        consumo_sm = new ArrayList<>();
        sensore_attivabile = new ArrayList<>();
        addon_sm = new ArrayList<>();

        //Sensori Attivabili
        nome_sa = new ArrayList<>();
        tipo_consumo_sa = new ArrayList<>();
        consumo_sa = new ArrayList<>();
        tempoAttivazione = new ArrayList<>();
        addon_sa = new ArrayList<>();

        //Creazione Cursori e Creazione errori
        int j;
        Cursor cursor = db.visualizzaSensoriMonitoraggio();
        int temp = cursor.getCount();
        cursor.moveToFirst();
        Cursor cursor1 = db.visualizzaSensoriAttivabili();
        cursor1.moveToFirst();
        System.out.println("Numero Sensori Monitoraggio: " + cursor.getCount());
        System.out.println("Numero Sensori Attivabili: " + cursor1.getCount());

        //While che gestisce tutte le auto attivazioni
        while (!exit) {

            //Tempo di attesa tra un errore e l'altro (Un minuto)
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            System.out.println("Mi stavo riposonado\n-----------------------------");

            //Numero randomico che utilizzo per creare allarmi sempre da sensori differenti
            int r = (int) (Math.random() * temp);
            System.out.println("RANDOM: " + r);
            if (cursor.getCount() == 0) {
                System.out.println("Errore Nessun Sensore Trovato");
            }
            //If che controlla che il cursore non sia null
            if (cursor != null && cursor.getCount() > 0) {
                if (cursor.isLast()) {
                    cursor.moveToFirst();
                    System.out.println("Fine Sensori Monitoraggio");
                }
                System.out.println("Sono Arrivato");
                //Scorro il cursore per ricavare i miei dati
                cursor.move(r);
                nome_sm.add(cursor.getString(0));
                tipo_consumo_sm.add(cursor.getString(1));
                consumo_sm.add(cursor.getString(2));
                sensore_attivabile.add(cursor.getString(3));
                addon_sm.add(cursor.getString(4));
                nomeConfronto = cursor.getString(3);
                System.out.println("Nome Confronto: " + nomeConfronto);
                cursor1.moveToFirst();
                //For per scorrere Tutta la Tabella del DataBase e confrontare il nomeConfronto col Nome del sensore
                for (j = 0; j < cursor1.getCount(); j++) {
                    if (cursor1.isLast()) {
                        System.out.println("Fine sensori Attivabili");
                        cursor1.moveToFirst();
                        cursor.moveToFirst();
                    }
                    cursor1.moveToNext();
                    nome_sa.add(cursor1.getString(0));
                    tipo_consumo_sa.add(cursor1.getString(1));
                    consumo_sa.add(cursor1.getString(2));
                    tempoAttivazione.add(cursor1.getString(3));
                    addon_sa.add(cursor1.getString(4));
                    nome = cursor1.getString(0);
                    System.out.println(nome);
                    tempoAttivazioneConfronto = cursor1.getInt(3);

                    //Se il nome confronto è uguale al nome di uno dei sensori attivabili allora mi sarvo in una coda il tempo di attivazione di quel sensore
                    // altrimenti visualizzo un messaggio di errore
                    if (nomeConfronto.equals(nome)) {
                        System.out.println("Sensore trovato Avvio Allarme" + "\n");
                        System.out.println("Tempo Attivazione: " + tempoAttivazioneConfronto);
                        coda.add(tempoAttivazioneConfronto);
                        System.out.println(coda);
                        //Tempo di attesa tra un errore e l'altro (Un minuto)
                        try {
                            Thread.sleep(10000);
                        } catch (InterruptedException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    } else {
                        System.out.println("Errore Nessun Sensore Trovato");

                    }
                }
            }
            cursor.moveToFirst();
        }
    }

    //Metodo per fermare il while
    public void stop(){
        exit = true;
    }

    //Metodo per attivare il while
    public void play(){
        exit = false;
    }
}