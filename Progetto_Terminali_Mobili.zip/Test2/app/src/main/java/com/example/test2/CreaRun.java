package com.example.test2;

import android.content.Context;
import android.database.Cursor;
import android.widget.Toast;

import com.example.test2.dataBase.GestioneDataBaseSQLite;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Queue;

public class CreaRun implements Runnable {

    private final Context context;
    CodaRun cr;
    GestioneDataBaseSQLite db;
    private volatile boolean exit = false;

    public CreaRun(Context context, CodaRun cr) {
        this.context = context;
        this.cr = cr;
    }

    public void run() {

        //Mi Prendo la Coda da CodaRun
        Queue<Integer> coda = cr.getCoda();
        int temp;

        //While per la gestione dell'autoattivazione
        while (!exit) {
            System.out.println("Sto in CreaRun");

            //If che controlla se la coda è vuota. Se la coda è vuota aspetta un minuto.
            if(coda.isEmpty()) {
                try {
                    Thread.sleep(60000);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                System.out.println("La coda è vuota");
            }

            //Else che gestisce il poll dalla queue e che moltiplica il tempo di attivazione * un minuto
            else {
                temp = coda.poll();
                System.out.println(coda + "\n-----------------------------");
                temp = temp*60000;
                System.out.println(temp + "\n-----------------------------");
                try {
                    Thread.sleep(temp);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                //Salvataggio nel DB dell'allarme
                SimpleDateFormat dateFormat = new SimpleDateFormat ("yyyy-MM-dd:kk:mm:ss");
                Date d = new Date();
                Calendar cal = Calendar.getInstance();
                cal.setTime(d);
                int minuti = temp /60000;
                cal.add(Calendar.MINUTE, -minuti);
                System.out.println("cal =" +cal);
                Date d1 = cal.getTime();
                String fine = dateFormat.format(d);
                System.out.println(fine + "\n-----------------------------");
                String inizio = dateFormat.format(d1);
                System.out.println(inizio + "\n-----------------------------");

                //DataBase
                db = new GestioneDataBaseSQLite(context);
                db.inserisciAllarmi(null, inizio, fine);
                System.out.println("Allarme inserito");
            }
            System.out.println("Coda ora contiene: " + coda + "\n-----------------------------");
        }
    }

    //Metodo per fermare il while
    public void stop(){
        exit = true;
    }

    //Metodo per attivare il while
    public void play(){
        exit = false;
    }

}
