package com.example.test2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.example.test2.dataBase.GestioneDataBaseSQLite;
import com.example.test2.schermateAdd.AddSensoriMonitoraggio;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class Fragment_Sensori_Monitoraggio extends Fragment {

    RecyclerView recyclerView;
    FloatingActionButton addSensoriMonitoraggio, aggiornaSensoriMonitorggio;
    GestioneDataBaseSQLite db;
    ArrayList<String> nome_sm, tipo_consumo_sm, consumo_sm, sensore_attivabile, addon_sm;
    CustomAdapter customAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment__sensori__monitoraggio, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewSensoriMonitoraggio);

        //Bottone che permette di accedere alla Activity AddSensoriMonitoraggio
        addSensoriMonitoraggio = (FloatingActionButton) view.findViewById(R.id.addSensoriMonitoraggio);
        addSensoriMonitoraggio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), AddSensoriMonitoraggio.class);
                startActivity(intent);
            }
        });

        //Bottone che permette di aggiornare il Fragment
        aggiornaSensoriMonitorggio = (FloatingActionButton) view.findViewById(R.id.aggiornaSensoriMonitoraggio);
        aggiornaSensoriMonitorggio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().recreate();
            }
        });


        //Accesso al Database e per salvare tutte le informazioni in una ArrayList
        db = new GestioneDataBaseSQLite(getActivity());
        nome_sm = new ArrayList<>();
        tipo_consumo_sm = new ArrayList<>();
        consumo_sm = new ArrayList<>();
        sensore_attivabile = new ArrayList<>();
        addon_sm = new ArrayList<>();

        visualizzaDati();

        //Chiamo il CustomAdapter per Riempiere la recyclerView
        customAdapter = new CustomAdapter(getActivity(), nome_sm, tipo_consumo_sm, consumo_sm, sensore_attivabile, addon_sm);
        System.out.println(customAdapter);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        return view;
    }

    //Metodo per aggiungere ad un Cursor tutti i Dati salvati dal DataBase
    void visualizzaDati() {
        Cursor cursor = db.visualizzaSensoriMonitoraggio();
        if (cursor.getCount() == 0) {
            //Toast.makeText(this, "NO DATA", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                nome_sm.add(cursor.getString(0));
                tipo_consumo_sm.add(cursor.getString(1));
                consumo_sm.add(cursor.getString(2));
                sensore_attivabile.add(cursor.getString(3));
                addon_sm.add(cursor.getString(4));
            }
        }
    }
}