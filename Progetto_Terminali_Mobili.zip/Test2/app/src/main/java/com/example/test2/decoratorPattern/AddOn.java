package com.example.test2.decoratorPattern;

/**
 * Classe con tutti i Constructors per il Decorator Pattern di AddOn.
 */

public class AddOn extends ExtraAdditionDecorator {

    public AddOn (Client client) {
        this.client = client;
    }

    @Override
    public String getTipoSensore() {
        return client.getTipoSensore();
    }

    @Override
    public String getNomeSensore() {
        return client.getNomeSensore() + " Add-On Agginto:";
    }

    @Override
    public int getConsumo() {
        return client.getConsumo();
    }
}

