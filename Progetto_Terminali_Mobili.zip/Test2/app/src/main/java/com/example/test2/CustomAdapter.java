package com.example.test2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.test2.schermateAdd.AddOn_Elimina_Activity;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    //Classe che utilizzo per la Gestione delle RecyclerView

    private Context context;
    private ArrayList nome_sm, tipo_consumo_sm, consumo_sm, sensore_attivabile, addon_sm;


    CustomAdapter(Context context, ArrayList nome_sm, ArrayList tipo_consumo_sm, ArrayList consumo_sm, ArrayList sensore_attivabile, ArrayList addon_sm){

        this.context = context;
        this.nome_sm = nome_sm;
        this.tipo_consumo_sm = tipo_consumo_sm;
        this.consumo_sm = consumo_sm;
        this.sensore_attivabile = sensore_attivabile;
        this.addon_sm = addon_sm;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.contenitore, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        holder.Nome_sensore_M.setText(String.valueOf(nome_sm.get(position)));
        holder.Tipo_Consumo_Sensore_M.setText(String.valueOf(tipo_consumo_sm.get(position)));
        holder.Consumo_Sensore_M.setText(String.valueOf(consumo_sm.get(position)));
        holder.Sensore_Attivabile_SM.setText(String.valueOf(sensore_attivabile.get(position)));
        holder.AddOn_Sensore_M.setText(String.valueOf(addon_sm.get(position)));

        holder.contenitore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, AddOn_Elimina_Activity.class);
                intent.putExtra("Nome", String.valueOf(nome_sm.get(position)));
                intent.putExtra("Tipo Consumo", String.valueOf(tipo_consumo_sm.get(position)));
                intent.putExtra("Consumo", String.valueOf(consumo_sm.get(position)));
                intent.putExtra("Sensore Attivabile", String.valueOf(sensore_attivabile.get(position)));
                intent.putExtra("AddOn", String.valueOf(addon_sm.get(position)));
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return nome_sm.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView Nome_sensore_M, Tipo_Consumo_Sensore_M, Consumo_Sensore_M, Sensore_Attivabile_SM, AddOn_Sensore_M;
        LinearLayout contenitore;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            Nome_sensore_M = itemView.findViewById(R.id.Nome_sensore_A);
            Tipo_Consumo_Sensore_M = itemView.findViewById(R.id.Tipo_Consumo_Sensore_A);
            Consumo_Sensore_M = itemView.findViewById(R.id.Consumo_Sensore_A);
            Sensore_Attivabile_SM = itemView.findViewById(R.id.Sensore_Attivabile_SA);
            AddOn_Sensore_M = itemView.findViewById(R.id.AddOn_Sensore_A);
            contenitore = itemView.findViewById(R.id.contenitore);
        }
    }
}
