package com.example.test2.schermateAdd;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.test2.R;
import com.example.test2.dataBase.GestioneDataBaseSQLite;

public class AddSensoriAttivabili extends AppCompatActivity {

    //Activity che Utilizzo per Creare un nuovo Sensore Attivabile

    EditText nome_sa, tipo_consumo_sa, consumo_sa, tempo_attivazione, addon_sa;
    Button bottone_salva;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_sensori_attivabili);


            nome_sa = findViewById(R.id.Nome_SA);
            tipo_consumo_sa = findViewById(R.id.Tipo_Consumo_SA);
            consumo_sa = findViewById(R.id.Consumo_SA);
            tempo_attivazione = findViewById(R.id.Tempo_Attivazione);
            addon_sa = findViewById(R.id.AddOn_SA);

            bottone_salva = findViewById(R.id.Salva_SA);
            bottone_salva.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    GestioneDataBaseSQLite db = new GestioneDataBaseSQLite(AddSensoriAttivabili.this);
                    db.inserisciSensoreAttivabili  (nome_sa.getText().toString().trim(),
                                                    tipo_consumo_sa.getText().toString().trim(),
                                                    Integer.valueOf(consumo_sa.getText().toString().trim()),
                                                    Integer.valueOf(tempo_attivazione.getText().toString().trim()),
                                                    addon_sa.getText().toString().trim());
                                                    finish();
                }
            });
        }
}