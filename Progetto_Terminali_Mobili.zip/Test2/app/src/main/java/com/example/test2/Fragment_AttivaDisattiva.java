package com.example.test2;

import android.app.Activity;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.test2.dataBase.GestioneDataBaseSQLite;

import java.util.ArrayList;
import java.util.Random;


public class Fragment_AttivaDisattiva extends Fragment {

    Button bottone_attiva;
    Button bottone_disattiva;
    private int i;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        CodaRun codaRun = new CodaRun(getActivity());
        Thread t = new Thread(codaRun);

        CreaRun creaRun = new CreaRun(getActivity(), codaRun);
        Thread z = new Thread(creaRun);

        i=0;

        View view = inflater.inflate(R.layout.fragment__attiva_disattiva, container, false);

        //Bottone per avviare tutti i sensori
        bottone_attiva = (Button) view.findViewById(R.id.buttonAttiva);
        bottone_attiva.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick (View v){
                    if(i!=0){
                        //Toast.makeText(getContext(), "Sensori Attivati", Toast.LENGTH_SHORT).show();
                        codaRun.play();
                        creaRun.play();
                        return;
                    }
                System.out.println("ciao");
                t.start();
                z.start();
                i=1;
                    //Toast.makeText(getContext(), "Sensori Attivati", Toast.LENGTH_SHORT).show();
            }
        });

        //Bottone per disattivare tutti i sensori
        bottone_disattiva = (Button) view.findViewById(R.id.buttonDisattiva);
        bottone_disattiva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                codaRun.stop();
                creaRun.stop();
                //Toast.makeText(getContext(), "Sensori Disattivati", Toast.LENGTH_SHORT).show();

            }
        });

        return view;
    }
}