package com.example.test2.schermateAdd;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.test2.R;
import com.example.test2.dataBase.GestioneDataBaseSQLite;
import com.example.test2.decoratorPattern.AddOn;
import com.example.test2.decoratorPattern.Client;
import com.example.test2.decoratorPattern.DP_SensoriAttivabili;
import com.example.test2.decoratorPattern.DP_SensoriMonitoraggio;

public class AddOn_Elimina_SA_Activity extends AppCompatActivity {

    EditText addOn_inputSA;
    Button buttonAggiungiSA, buttonEliminaSA;
    String addOn_sa, nome_sa;
    String consumo_sa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_on_elimina_sa);

        addOn_inputSA = findViewById(R.id.add_addOnSA);
        buttonAggiungiSA = findViewById(R.id.buttonAggiungiSA);

        //Avvio i setter e i getter per aggiungere gli addon al mio database
        get_Set_Data();

        //metto nella action bar il nome del sensore che sto modificando/eliminando
        ActionBar ab = getSupportActionBar();
        if(ab!=null){
            ab.setTitle(nome_sa);
        }

        buttonAggiungiSA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Avvio il Decorator Pattern.
                Client aggiungiConsumoSA = new AddOn(new DP_SensoriAttivabili());
                GestioneDataBaseSQLite db = new GestioneDataBaseSQLite(AddOn_Elimina_SA_Activity.this);
                addOn_sa = addOn_inputSA.getText().toString().trim();
                int consumo = Integer.parseInt(consumo_sa);
                System.out.println(consumo);
                consumo = consumo + aggiungiConsumoSA.getConsumo();
                System.out.println(consumo);
                db.aggiungiAddOnSA(nome_sa, addOn_sa, consumo);
                finish();
            }
        });
        buttonEliminaSA = findViewById(R.id.buttonEliminaSensoreSA);
        buttonEliminaSA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GestioneDataBaseSQLite db = new GestioneDataBaseSQLite(AddOn_Elimina_SA_Activity.this);
                db.cancellaSensoreAttivabile(nome_sa);
            }
        });
    }

    private void get_Set_Data() {
        if (getIntent().hasExtra("Nome") && getIntent().hasExtra("Tipo Consumo") && getIntent().hasExtra("Consumo") && getIntent().hasExtra("Tempo Attivazione") && getIntent().hasExtra("AddOn")){

            //Get
            nome_sa = getIntent().getStringExtra("Nome");
            System.out.println(nome_sa);
            addOn_sa = getIntent().getStringExtra("AddOn");
            consumo_sa = getIntent().getStringExtra("Consumo");

            //Set
            addOn_inputSA.setText(addOn_sa);
        }
        else{
            Toast.makeText(this, "Errore", Toast.LENGTH_LONG).show();
        }
    }
}
