package com.example.test2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.ActionBar;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    //Main Activity che utilizzo come schermata di informazione sull'app e per cambiare i vari fragment.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.navigation_view);

        //ToolBar per gestire la sostituzione dei vari Fragment
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull @org.jetbrains.annotations.NotNull MenuItem item) {

                int id = item.getItemId();
                item.setCheckable(true);
                drawerLayout.closeDrawer(GravityCompat.START);
                switch (id) {
                    case R.id.Attiva:
                        replaceFragment(new Fragment_AttivaDisattiva());
                        break;
                    case R.id.Sensori_Monitoraggio:
                        replaceFragment(new Fragment_Sensori_Monitoraggio());
                        break;
                    case R.id.Sensori_Attivabili:
                        replaceFragment(new Fragment_Sensori_Attivabili());
                        break;
                    case R.id.Allarmi:
                        replaceFragment(new Fragment_Allarmi());
                        break;
                    default:
                        return true;
                }
                return true;
            }
        });
    }

    //Metodo per sostituire i Fragment
    private void replaceFragment (Fragment fragment) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frameLayout, fragment);
            fragmentTransaction.commit();
        }
}