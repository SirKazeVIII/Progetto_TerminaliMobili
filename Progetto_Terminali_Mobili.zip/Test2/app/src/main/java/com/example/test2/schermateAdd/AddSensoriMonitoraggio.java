package com.example.test2.schermateAdd;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.provider.Telephony;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.test2.Fragment_AttivaDisattiva;
import com.example.test2.Fragment_Sensori_Monitoraggio;
import com.example.test2.R;
import com.example.test2.dataBase.GestioneDataBaseSQLite;

public class AddSensoriMonitoraggio extends AppCompatActivity {

    //Activity che Utilizzo per Creare un nuovo Sensore Monitoraggio

    EditText nome_sm, tipo_consumo_sm, consumo_sm, sensore_attivabile, addon_sm;
    Button bottone_salva;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_sensori_monitoraggio);
        nome_sm = findViewById(R.id.Nome_SM);
        tipo_consumo_sm = findViewById(R.id.Tipo_Consumo_SM);
        consumo_sm = findViewById(R.id.Consumo_SM);
        sensore_attivabile = findViewById(R.id.Sensore_Attivabile);
        addon_sm = findViewById(R.id.AddOn_SM);

        bottone_salva = findViewById(R.id.Salva_SM);
        bottone_salva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GestioneDataBaseSQLite db = new GestioneDataBaseSQLite(AddSensoriMonitoraggio.this);
                db.inserisciSensoreMonitoraggio(nome_sm.getText().toString().trim(),
                        tipo_consumo_sm.getText().toString().trim(),
                        Integer.valueOf(consumo_sm.getText().toString().trim()),
                        sensore_attivabile.getText().toString().trim(),
                        addon_sm.getText().toString().trim());
                        finish();
            }
        });
    }
}
