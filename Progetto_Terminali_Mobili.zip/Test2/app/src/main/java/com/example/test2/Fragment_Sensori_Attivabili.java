package com.example.test2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.test2.dataBase.GestioneDataBaseSQLite;
import com.example.test2.schermateAdd.AddSensoriAttivabili;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class Fragment_Sensori_Attivabili extends Fragment {

    RecyclerView recyclerView;
    FloatingActionButton addSensoriMonitoraggio, aggiornaSensoriAttivabili;
    GestioneDataBaseSQLite db;
    ArrayList<String> nome_sa, tipo_consumo_sa, consumo_sa, tempoAttivazione, addon_sa;
    CustomAdapterSA customAdapterSA;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment__sensori__attivabili, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewSensoriAttivabili);

        //Bottone che permette di accedere alla Activity AddSensoriAttivabili
        addSensoriMonitoraggio = (FloatingActionButton) view.findViewById(R.id.addSensoriAttivabili);
        addSensoriMonitoraggio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), AddSensoriAttivabili.class);
                startActivity(intent);
            }
        });

        //Bottone che permette di aggiornare il Fragment
        aggiornaSensoriAttivabili = (FloatingActionButton) view.findViewById(R.id.aggiornaSensoriAttivabili);
        aggiornaSensoriAttivabili.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().recreate();
            }
        });


        //Accesso al Database e per salvare tutte le informazioni in una ArrayList
        db = new GestioneDataBaseSQLite(getActivity());
        nome_sa = new ArrayList<>();
        tipo_consumo_sa = new ArrayList<>();
        consumo_sa = new ArrayList<>();
        tempoAttivazione = new ArrayList<>();
        addon_sa = new ArrayList<>();

        visualizzaDati();

        //Chiamo il CustomAdapter per Riempiere la recyclerView
        customAdapterSA = new CustomAdapterSA(getActivity(), nome_sa, tipo_consumo_sa, consumo_sa, tempoAttivazione, addon_sa);
        System.out.println(customAdapterSA);
        recyclerView.setAdapter(customAdapterSA);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        return view;
    }

    //Metodo per aggiungere ad un Cursor tutti i Dati salvati dal DataBase
    void visualizzaDati() {
        Cursor cursor = db.visualizzaSensoriAttivabili();
        if (cursor.getCount() == 0) {
            //Toast.makeText(this, "NO DATA", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                nome_sa.add(cursor.getString(0));
                tipo_consumo_sa.add(cursor.getString(1));
                consumo_sa.add(cursor.getString(2));
                tempoAttivazione.add(cursor.getString(3));
                addon_sa.add(cursor.getString(4));
            }
        }
    }
}