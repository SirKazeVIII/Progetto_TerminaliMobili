package com.example.test2.decoratorPattern;

public class DP_SensoriMonitoraggio extends Client{

    public DP_SensoriMonitoraggio () {
        TipoSensore = "Sensore Monitoraggio";
    }

    @Override
    public String getNomeSensore() {
        return null;
    }

    @Override
    public int getConsumo() {
        return 5;
    }
}
