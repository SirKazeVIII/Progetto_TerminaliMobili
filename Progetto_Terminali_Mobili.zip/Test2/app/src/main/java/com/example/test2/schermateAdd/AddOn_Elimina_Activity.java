package com.example.test2.schermateAdd;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.test2.Fragment_Sensori_Monitoraggio;
import com.example.test2.MainActivity;
import com.example.test2.R;
import com.example.test2.dataBase.GestioneDataBaseSQLite;
import com.example.test2.decoratorPattern.AddOn;
import com.example.test2.decoratorPattern.Client;
import com.example.test2.decoratorPattern.DP_SensoriAttivabili;
import com.example.test2.decoratorPattern.DP_SensoriMonitoraggio;

public class AddOn_Elimina_Activity extends AppCompatActivity {

    EditText addOn_input;
    Button buttonAggiungi, buttonElimina;
    String addOn, nome_sm;
    String consumo_sm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_on_elimina);

        addOn_input = findViewById(R.id.add_addOn);
        buttonAggiungi = findViewById(R.id.buttonAggiungi);

        //Avvio i setter e i getter per aggiungere gli addon al mio database
        get_Set_Data();

        //metto nella action bar il nome del sensore che sto modificando/eliminando
        ActionBar ab = getSupportActionBar();
        if(ab!=null){
            ab.setTitle(nome_sm);
        }

        buttonAggiungi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Avvio il Decorator Pattern.
                Client aggiungiConsumoSM = new AddOn(new DP_SensoriMonitoraggio());
                GestioneDataBaseSQLite db = new GestioneDataBaseSQLite(AddOn_Elimina_Activity.this);
                addOn = addOn_input.getText().toString().trim();
                int consumo = Integer.parseInt(consumo_sm);
                System.out.println(consumo);
                consumo = consumo + aggiungiConsumoSM.getConsumo();
                System.out.println(consumo);
                db.aggiungiAddOnSM(nome_sm, addOn, consumo);
                finish();
            }
        });
        buttonElimina = findViewById(R.id.buttonEliminaSensore);
        buttonElimina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GestioneDataBaseSQLite db = new GestioneDataBaseSQLite(AddOn_Elimina_Activity.this);
                db.cancellaSensoreMonitoraggio(nome_sm);
            }
        });
    }

    void get_Set_Data(){
        System.out.println("ciao");
        if (getIntent().hasExtra("Nome") && getIntent().hasExtra("Tipo Consumo") && getIntent().hasExtra("Consumo") && getIntent().hasExtra("Sensore Attivabile") && getIntent().hasExtra("AddOn")){

            //Get
            nome_sm = getIntent().getStringExtra("Nome");
            System.out.println(nome_sm);
            addOn = getIntent().getStringExtra("AddOn");
            consumo_sm = getIntent().getStringExtra("Consumo");

            //Set
            addOn_input.setText(addOn);
        }
        else{
            System.out.println("ciao2");
            Toast.makeText(this, "Errore", Toast.LENGTH_LONG).show();
        }
    }
}