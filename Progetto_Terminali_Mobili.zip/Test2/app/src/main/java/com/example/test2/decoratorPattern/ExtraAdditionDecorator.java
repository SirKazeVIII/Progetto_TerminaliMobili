package com.example.test2.decoratorPattern;

/**
 * Classe che estende la classe Client.
 */

public abstract class ExtraAdditionDecorator extends Client {
    protected Client client;

    @Override
    public abstract String getTipoSensore();
}
