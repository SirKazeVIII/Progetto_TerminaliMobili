package com.example.test2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.test2.dataBase.GestioneDataBaseSQLite;
import com.example.test2.schermateAdd.AddSensoriAttivabili;
import com.example.test2.schermateAdd.AddSensoriMonitoraggio;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


public class Fragment_Allarmi extends Fragment {

    RecyclerView recyclerView;
    GestioneDataBaseSQLite db;
    ArrayList<String> id, data_inizio, data_fine;
    CustomAdapterAllarmi customAdapterAllarmi;
    FloatingActionButton eliminaAllarmi, aggiornaAllarmi;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment__allarmi, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewAllarmi);

        //Accesso al Database e per salvare tutte le informazioni in una ArrayList
        db = new GestioneDataBaseSQLite(getActivity());
        id = new ArrayList<>();
        data_inizio = new ArrayList<>();
        data_fine = new ArrayList<>();

        visualizzaDati();

        //Chiamo il CustomAdapter per Riempiere la recyclerView
        customAdapterAllarmi = new CustomAdapterAllarmi (getActivity(), id, data_inizio, data_fine);
        System.out.println(customAdapterAllarmi);
        recyclerView.setAdapter(customAdapterAllarmi);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        //Bottone che permette di Eliminare tutti gli Allarmi
        eliminaAllarmi = (FloatingActionButton)  view.findViewById(R.id.eliminaAllarmi);
        eliminaAllarmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.resetAllarmi();
                getActivity().recreate();
            }
        });

        //Bottone che permette di aggiornare il Fragment
        aggiornaAllarmi = (FloatingActionButton) view.findViewById(R.id.aggiornaAllarme);
        aggiornaAllarmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().recreate();
            }
        });

        return view;
    }

    //Metodo per aggiungere ad un Cursor tutti i Dati salvati dal DataBase
    void visualizzaDati(){
        Cursor cursor = db.visualizzaAllarmi();
        if(cursor.getCount() == 0){
            //Toast.makeText(this, "NO DATA", Toast.LENGTH_SHORT).show();
        }
        else{
            while (cursor.moveToNext()){
                id.add(cursor.getString(0));
                data_inizio.add(cursor.getString(1));
                data_fine.add(cursor.getString(2));
            }
        }
    }
}