package com.example.test2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapterAllarmi extends RecyclerView.Adapter<CustomAdapterAllarmi.MyViewHolderAllarmi> {

    //Classe che utilizzo per la Gestione delle RecyclerView

    private Context context;
    private ArrayList id, data_inizio, data_fine;

    CustomAdapterAllarmi(Context context, ArrayList id, ArrayList data_inizio, ArrayList data_fine) {

        this.context = context;
        this.id = id;
        this.data_inizio = data_inizio;
        this.data_fine = data_fine;
    }

    @NonNull
    @Override
    public CustomAdapterAllarmi.MyViewHolderAllarmi onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.contenitore_allarmi, parent, false);
        return new MyViewHolderAllarmi(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolderAllarmi holder, int position) {
        holder.ID.setText(String.valueOf(id.get(position)));
        holder.Data_inizio.setText(String.valueOf(data_inizio.get(position)));
        holder.Data_fine.setText(String.valueOf(data_fine.get(position)));
    }

    @Override
    public int getItemCount() {
        return id.size();
    }

    public class MyViewHolderAllarmi extends RecyclerView.ViewHolder {
        TextView ID, Data_inizio, Data_fine;

        public MyViewHolderAllarmi(@NonNull View itemView) {
            super(itemView);
            ID = itemView.findViewById(R.id.ID);
            Data_inizio = itemView.findViewById(R.id.Data_inizio);
            Data_fine = itemView.findViewById(R.id.Data_fine);

        }
    }
}