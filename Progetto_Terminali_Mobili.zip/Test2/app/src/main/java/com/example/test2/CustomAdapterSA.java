package com.example.test2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.test2.schermateAdd.AddOn_Elimina_SA_Activity;

import java.util.ArrayList;

public class CustomAdapterSA extends RecyclerView.Adapter<CustomAdapterSA.MyViewHolderSA> {

    //Classe che utilizzo per la Gestione delle RecyclerView

    private Context context;
    private ArrayList nome_sa, tipo_consumo_sa, consumo_sa, tempoAttivazione, addon_sa;

    CustomAdapterSA(Context context, ArrayList nome_sa, ArrayList tipo_consumo_sa, ArrayList consumo_sa, ArrayList tempoAttivazione, ArrayList addon_sa){

        this.context = context;
        this.nome_sa = nome_sa;
        this.tipo_consumo_sa = tipo_consumo_sa;
        this.consumo_sa = consumo_sa;
        this.tempoAttivazione = tempoAttivazione;
        this.addon_sa = addon_sa;

    }

    @NonNull
    @Override
    public MyViewHolderSA onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.contenitore_sa, parent, false);
        return new MyViewHolderSA(view);
    }

    @Override
    public void onBindViewHolder (@NonNull final MyViewHolderSA holder, final int position) {
        holder.Nome_sensore_A.setText(String.valueOf(nome_sa.get(position)));
        holder.Tipo_Consumo_Sensore_A.setText(String.valueOf(tipo_consumo_sa.get(position)));
        holder.Consumo_Sensore_A.setText(String.valueOf(consumo_sa.get(position)));
        holder.TempoAttivazione.setText(String.valueOf(tempoAttivazione.get(position)));
        holder.AddOn_Sensore_A.setText(String.valueOf(addon_sa.get(position)));

        holder.contenitoreSA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, AddOn_Elimina_SA_Activity.class);
                intent.putExtra("Nome", String.valueOf(nome_sa.get(position)));
                intent.putExtra("Tipo Consumo", String.valueOf(tipo_consumo_sa.get(position)));
                intent.putExtra("Consumo", String.valueOf(consumo_sa.get(position)));
                intent.putExtra("Tempo Attivazione", String.valueOf(tempoAttivazione.get(position)));
                intent.putExtra("AddOn", String.valueOf(addon_sa.get(position)));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return nome_sa.size();
    }

    public class MyViewHolderSA extends RecyclerView.ViewHolder{

        TextView Nome_sensore_A, Tipo_Consumo_Sensore_A, Consumo_Sensore_A, TempoAttivazione, AddOn_Sensore_A;
        LinearLayout contenitoreSA;

        public MyViewHolderSA(@NonNull View itemView) {
            super(itemView);
            Nome_sensore_A = itemView.findViewById(R.id.Nome_sensore_A);
            Tipo_Consumo_Sensore_A = itemView.findViewById(R.id.Tipo_Consumo_Sensore_A);
            Consumo_Sensore_A = itemView.findViewById(R.id.Consumo_Sensore_A);
            TempoAttivazione = itemView.findViewById(R.id.Sensore_Attivabile_SA);
            AddOn_Sensore_A = itemView.findViewById(R.id.AddOn_Sensore_A);
            contenitoreSA = itemView.findViewById(R.id.contenitore_sa);
        }
    }
    }